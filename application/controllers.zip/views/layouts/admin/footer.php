</div>

                <!-- Footer Area -->
                
            </div>
        </div>
    </div>


    <!-- ======================================
    ********* Page Wrapper Area End ***********
    ======================================= -->

    <!-- Must needed plugins to the run this Template -->
    <script src="<?php echo base_url(); ?>public/riktheme/js/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>public/riktheme/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>public/riktheme/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>public/riktheme/js/bundle.js"></script>

    <!-- Active JS -->
    <script src="<?php echo base_url(); ?>public/riktheme/js/default-assets/fullscreen.js"></script>
    <script src="<?php echo base_url(); ?>public/riktheme/js/default-assets/active.js"></script>

    <!-- These plugins only need for the run this page -->
    <script src="<?php echo base_url(); ?>public/riktheme/js/default-assets/dashboard-chat.js"></script>

</body>


</html>