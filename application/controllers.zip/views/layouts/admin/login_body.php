<?php
   include("./application/views/".$_view.".php"); 
?>