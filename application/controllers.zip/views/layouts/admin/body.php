<?php
   include("header.php");
      include("./application/views/".$_view.".php"); 
   include("footer.php");
?>