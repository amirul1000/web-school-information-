 </div>
 </div>
</section>
<footer id="footer">
	<div class="footer_top">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-3" >
					<div class="single_footer_widget">
				    	<h3 style="font-size:18px" ><a href="<?php echo site_url('content/index/?cn='.urlencode('Club and Society'))?>" style="color:#000080;">Contact</a></h3>
							<p title="address">
								<strong><i class="fa fa-map-marker" aria-hidden="true"></i> BEPZA PUBLIC SCHOOL AND COLLEGE (BPSC)

</strong><br />
					Savar, Dhaka – 1349<br />
								<i class="fa fa-volume-control-phone" aria-hidden="true">  8961163</i><br />
								<i class="fa fa-envelope-o" aria-hidden="true">bepzasc@yahoo.com</i>
							</p>
					</div>
				</div>
				<div class="col-xs-12 col-sm-3">
					<div class="single_footer_widget">
						<h3 style="font-size:18px">FEATURED LINKS</h3>
						<ul class="footer_widget_nav">
							<li><a href="http://www.educationboard.gov.bd/" target="_blank">&raquo; Education Board</a></li>
							<li><a href="http://www.educationboard.gov.bd/" target="_blank">&raquo; Dhaka Education Board</a></li>
							<li><a href="http://www.moedu.gov.bd/" target="_blank">&raquo; Ministry of Education</a></li>
							<li><a class="http://banbeis.gov.bd/new/" target="_blank">&raquo; Banbeis</a>	</li>
							<li><a href="http://www.dshe.gov.bd/" target="_blank">&raquo; Directorate of Secondary & Higher Education</a></li>
							<li><a href="http://www.nctb.gov.bd/" target="_blank">&raquo; NCTB</a></li>
						</ul>
					</div>
				</div>
				<div class="col-xs-12 col-sm-3">
					<div class="single_footer_widget">
						<h3 style="font-size:18px">Social Links</h3>
						<div class="fb-page" data-href="https://www.facebook.com/groups/1656785201247661" data-width="460"  data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" data-show-posts="false"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/facebook"><a href="https://www.facebook.com/facebook">Facebook</a></blockquote></div></div>
					</div>
				</div>
						<div class="col-xs-12 col-sm-3">
					<div class="single_footer_widget text-center">
						<h3 style="font-size:18px;">Visitor Counter</h3>
					   						<table class="table" style="background-color:lightgreen">
							  <tbody style="text-align:left">
									<tr class="">
							      <td>Today</td>
							      <td>26</td>
							    </tr>
                                	<tr class="">
							      <td>This Week</td>
							      <td>4261</td>
							    </tr>
									<tr class="">
							      <td>This Month</td>
							      <td>1331</td>
							    </tr>
									<tr class="">
							      <td>This Year</td>
							      <td>54789</td>
							    </tr>
									<tr class="">
							      <td>Total</td>
							      <td>300035</td>
							    </tr>
							  </tbody>
							</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row footer-bottom-under">
		<div class="container" align="center" style="padding-top:7px !important;padding-bottom:7px;">© 2022 - BEPZA PUBLIC SCHOOL AND COLLEGE (BPSC) All Rights Reserved. &emsp; Developed by
		 <a href="https://www.facebook.com/Patacorporation-221757433140866" target="blank" style="color:blue;">Pata Corporation.</a>
		  <a href="https://www.facebook.com/BEPZA-Public-School-College-Ishwardi-EPZ-Paksey-Pabna-240678287099103/?ref=page_internal" target="_blank"> Like us on <span style="color:coral;">Facebook</span></a>
	  </div>
 </div>
</footer>

<!--	<script src="<?php echo base_url(); ?>public/front/js/scripts.js"></script>-->
<script defer src="<?php echo base_url(); ?>public/front/js/SmoothScroll.min.js"></script>
<script defer src="cdn.jsdelivr.net/gh/pguso/jquery-plugin-circliful%40master/js/jquery.circliful.min.js"></script>
<script src="<?php echo base_url(); ?>public/front/js/indexScript.js"></script>
<!--
<script src="<?php echo base_url(); ?>public/front/js/slider.service.js"></script>-->
<script src="<?php echo base_url(); ?>public/front/js/indexContent.ctrl.js"></script>

<script>
  $('#myCarousel').carousel({
    interval:   4000
  });
</script>


</body>

</html>
